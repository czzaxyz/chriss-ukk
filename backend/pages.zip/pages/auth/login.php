

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Sistem Peminjaman Motor</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Custom CSS -->
    <style>
        :root {
            --primary-color: #4e73df;
            --secondary-color: #1cc88a;
            --danger-color: #e74a3b;
            --warning-color: #f6c23e;
            --dark-color: #5a5c69;
            --light-color: #f8f9fc;
        }
        
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            height: 100vh;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0;
            padding: 20px;
        }
        
        .login-container {
            width: 100%;
            max-width: 420px;
        }
        
        .login-card {
            background: white;
            border-radius: 15px;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            animation: fadeIn 0.5s ease-out;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .card-header {
            background: linear-gradient(135deg, #4e73df 0%, #224abe 100%);
            color: white;
            padding: 30px 20px;
            text-align: center;
            border-bottom: none;
        }
        
        .brand-logo {
            font-size: 2rem;
            font-weight: 700;
            margin-bottom: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
        }
        
        .brand-logo i {
            background: white;
            color: #4e73df;
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .welcome-text {
            font-size: 1rem;
            opacity: 0.9;
            margin-bottom: 0;
        }
        
        .card-body {
            padding: 30px;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-label {
            font-weight: 600;
            color: var(--dark-color);
            margin-bottom: 8px;
            display: block;
        }
        
        .input-group-custom {
            position: relative;
            display: flex;
            align-items: center;
        }
        
        .input-group-custom .form-control {
            padding-left: 45px;
            height: 50px;
            border-radius: 8px;
            border: 2px solid #e3e6f0;
            transition: all 0.3s;
            font-size: 1rem;
        }
        
        .input-group-custom .form-control:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 0.2rem rgba(78, 115, 223, 0.25);
        }
        
        .input-icon {
            position: absolute;
            left: 15px;
            color: #858796;
            font-size: 1.2rem;
            z-index: 4;
        }
        
        .btn-login {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border: none;
            border-radius: 8px;
            padding: 14px;
            font-weight: 600;
            font-size: 1.1rem;
            color: white;
            width: 100%;
            transition: all 0.3s;
            margin-top: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
        }
        
        .btn-login:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(102, 126, 234, 0.3);
        }
        
        .btn-login:active {
            transform: translateY(0);
        }
        
        .register-link {
            text-align: center;
            margin-top: 20px;
            color: #6c757d;
        }
        
        .register-link a {
            color: var(--primary-color);
            text-decoration: none;
            font-weight: 600;
            transition: color 0.3s;
        }
        
        .register-link a:hover {
            color: #224abe;
            text-decoration: underline;
        }
        
        /* Alert Styles */
        .alert-custom {
            border-radius: 10px;
            border: none;
            padding: 15px 20px;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            animation: slideIn 0.3s ease-out;
        }
        
        @keyframes slideIn {
            from { transform: translateX(-20px); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
        }
        
        .alert-danger-custom {
            background: linear-gradient(135deg, #f8d7da 0%, #f5c6cb 100%);
            border-left: 4px solid var(--danger-color);
            color: #721c24;
        }
        
        .alert-success-custom {
            background: linear-gradient(135deg, #d4edda 0%, #c3e6cb 100%);
            border-left: 4px solid var(--secondary-color);
            color: #155724;
        }
        
        .alert-warning-custom {
            background: linear-gradient(135deg, #fff3cd 0%, #ffeaa7 100%);
            border-left: 4px solid var(--warning-color);
            color: #856404;
        }
        
        .alert-icon {
            font-size: 1.5rem;
            margin-right: 12px;
        }
        
        /* Password Toggle */
        .password-toggle {
            position: absolute;
            right: 15px;
            background: none;
            border: none;
            color: #858796;
            cursor: pointer;
            z-index: 5;
        }
        
        /* Demo Info */
        .demo-info {
            background: linear-gradient(135deg, #f8f9fc 0%, #e3e6f0 100%);
            border-radius: 10px;
            padding: 15px;
            margin-top: 20px;
            border-left: 4px solid var(--primary-color);
        }
        
        .demo-info h6 {
            color: var(--primary-color);
            font-weight: 600;
            margin-bottom: 10px;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .demo-info ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        
        .demo-info li {
            padding: 5px 0;
            color: var(--dark-color);
            font-size: 0.9rem;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .demo-info li i {
            color: var(--primary-color);
            font-size: 0.8rem;
        }
        
        /* Responsive */
        @media (max-width: 576px) {
            .login-card {
                border-radius: 10px;
            }
            
            .card-header {
                padding: 20px;
            }
            
            .card-body {
                padding: 20px;
            }
            
            .brand-logo {
                font-size: 1.5rem;
            }
        }
    </style>
</head>

<body>
    <div class="login-container">
        <div class="login-card">
            <!-- Card Header -->
            <div class="card-header">
                <div class="brand-logo">
                    <i class="fas fa-tools"></i>
                    <span>Peminjaman Motor</span>
                </div>
                <p class="welcome-text">Selamat Datang di Sistem Peminjaman Motor</p>
            </div>
            
            <!-- Card Body -->
            <div class="card-body">
                <!-- Session Messages -->
                <?php 
                if (isset($_SESSION['register_success'])): ?>
                    <div class="alert-custom alert-success-custom">
                        <i class="fas fa-check-circle alert-icon"></i>
                        <div>
                            <?php 
                            echo $_SESSION['register_success'];
                            unset($_SESSION['register_success']);
                            ?>
                        </div>
                    </div>
                <?php endif; ?>
                
                <?php if (isset($_SESSION['logout_success'])): ?>
                    <div class="alert-custom alert-success-custom">
                        <i class="fas fa-check-circle alert-icon"></i>
                        <div>
                            <?php 
                            echo $_SESSION['logout_success'];
                            unset($_SESSION['logout_success']);
                            ?>
                        </div>
                    </div>
                <?php endif; ?>
                
                <?php if (isset($_SESSION['login_error'])): ?>
                    <div class="alert-custom alert-danger-custom">
                        <i class="fas fa-exclamation-triangle alert-icon"></i>
                        <div>
                            <?php 
                            echo $_SESSION['login_error'];
                            unset($_SESSION['login_error']);
                            ?>
                        </div>
                    </div>
                <?php endif; ?>
                
                <!-- URL Parameter Messages -->
                <?php if (isset($_GET['pesan']) && $_GET['pesan'] == 'gagal'): ?>
                    <div class="alert-custom alert-danger-custom">
                        <i class="fas fa-exclamation-triangle alert-icon"></i>
                        <div>Username atau password salah!</div>
                    </div>
                <?php endif; ?>
                
                <?php if (isset($_GET['pesan']) && $_GET['pesan'] == 'logout'): ?>
                    <div class="alert-custom alert-success-custom">
                        <i class="fas fa-check-circle alert-icon"></i>
                        <div>Anda berhasil logout!</div>
                    </div>
                <?php endif; ?>
                
                <?php if (isset($_GET['pesan']) && $_GET['pesan'] == 'belum_login'): ?>
                    <div class="alert-custom alert-warning-custom">
                        <i class="fas fa-exclamation-circle alert-icon"></i>
                        <div>Silakan login terlebih dahulu!</div>
                    </div>
                <?php endif; ?>

                <!-- Form Login -->
                <form action="../../../backend/action/auth/login_proses.php" method="POST" id="loginForm">
                    <!-- Username -->
                    <div class="form-group">
                        <label for="username" class="form-label">Username</label>
                        <div class="input-group-custom">
                            <i class="fas fa-user input-icon"></i>
                            <input type="text" class="form-control" id="username" name="username" 
                                   placeholder="Masukkan username Anda" required>
                        </div>
                    </div>
                    
                    <!-- Password -->
                    <div class="form-group">
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <label for="password" class="form-label">Password</label>
                            <button type="button" class="btn btn-link btn-sm p-0" style="color: var(--primary-color);" 
                                    onclick="togglePassword()">
                                <i class="fas fa-eye"></i> Tampilkan
                            </button>
                        </div>
                        <div class="input-group-custom">
                            <i class="fas fa-lock input-icon"></i>
                            <input type="password" class="form-control" id="password" name="password" 
                                   placeholder="Masukkan password Anda" required>
                        </div>
                    </div>

                    <!-- Submit Button -->
                    <button type="submit" class="btn btn-login" id="loginBtn">
                        <i class="fas fa-sign-in-alt"></i>
                        <span id="btnText">Login</span>
                        <span id="btnLoading" class="d-none">
                            <span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
                            Memproses...
                        </span>
                    </button>
                    
                    <!-- Register Link -->
                    <div class="register-link">
                        Belum punya akun? <a href="register.php">Daftar di sini</a>
                    </div>
                </form>
                <!-- End Form Login -->
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
        // Password Toggle
        function togglePassword() {
            const passwordInput = document.getElementById('password');
            const toggleBtn = document.querySelector('[onclick="togglePassword()"]');
            const icon = toggleBtn.querySelector('i');
            
            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';
                icon.classList.remove('fa-eye');
                icon.classList.add('fa-eye-slash');
                toggleBtn.innerHTML = '<i class="fas fa-eye-slash"></i> Sembunyikan';
            } else {
                passwordInput.type = 'password';
                icon.classList.remove('fa-eye-slash');
                icon.classList.add('fa-eye');
                toggleBtn.innerHTML = '<i class="fas fa-eye"></i> Tampilkan';
            }
        }
        
        // Form Submission Loading
        document.getElementById('loginForm').addEventListener('submit', function(e) {
            const loginBtn = document.getElementById('loginBtn');
            const btnText = document.getElementById('btnText');
            const btnLoading = document.getElementById('btnLoading');
            
            // Disable button and show loading
            loginBtn.disabled = true;
            btnText.classList.add('d-none');
            btnLoading.classList.remove('d-none');
            
            // Prevent double submission
            setTimeout(() => {
                if (!loginBtn.disabled) {
                    loginBtn.disabled = false;
                    btnText.classList.remove('d-none');
                    btnLoading.classList.add('d-none');
                }
            }, 3000);
        });
        
        // Auto focus on username field
        document.addEventListener('DOMContentLoaded', function() {
            document.getElementById('username').focus();
            
            // Clear URL parameters to prevent showing alerts on refresh
            if (window.history.replaceState) {
                window.history.replaceState(null, null, window.location.pathname);
            }
        });
        
        // Input validation
        const usernameInput = document.getElementById('username');
        const passwordInput = document.getElementById('password');
        
        usernameInput.addEventListener('input', function() {
            if (this.value.length < 3) {
                this.style.borderColor = 'var(--danger-color)';
            } else {
                this.style.borderColor = 'var(--primary-color)';
            }
        });
        
        passwordInput.addEventListener('input', function() {
            if (this.value.length < 6) {
                this.style.borderColor = 'var(--danger-color)';
            } else {
                this.style.borderColor = 'var(--primary-color)';
            }
        });
        
        // Add enter key support
        document.addEventListener('keypress', function(e) {
            if (e.key === 'Enter' && !document.getElementById('loginBtn').disabled) {
                document.getElementById('loginForm').submit();
            }
        });
    </script>
</body>
</html>