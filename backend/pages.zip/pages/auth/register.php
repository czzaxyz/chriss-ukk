<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - Sistem Peminjaman Motor</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Custom CSS -->
    <style>
        :root {
            --primary-color: #4e73df;
            --secondary-color: #1cc88a;
            --danger-color: #e74a3b;
            --warning-color: #f6c23e;
            --dark-color: #5a5c69;
            --light-color: #f8f9fc;
        }
        
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0;
            padding: 20px;
        }
        
        .register-container {
            width: 100%;
            max-width: 800px;
        }
        
        .register-card {
            background: white;
            border-radius: 15px;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            animation: fadeIn 0.5s ease-out;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .card-header {
            background: linear-gradient(135deg, #4e73df 0%, #224abe 100%);
            color: white;
            padding: 30px;
            text-align: center;
            border-bottom: none;
        }
        
        .brand-logo {
            font-size: 2rem;
            font-weight: 700;
            margin-bottom: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
        }
        
        .brand-logo i {
            background: white;
            color: #4e73df;
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .welcome-text {
            font-size: 1rem;
            opacity: 0.9;
            margin-bottom: 0;
        }
        
        .card-body {
            padding: 30px;
        }
        
        .form-title {
            color: var(--primary-color);
            font-weight: 700;
            margin-bottom: 25px;
            font-size: 1.5rem;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-label {
            font-weight: 600;
            color: var(--dark-color);
            margin-bottom: 8px;
            display: block;
        }
        
        .form-label.required:after {
            content: " *";
            color: var(--danger-color);
        }
        
        .input-group-custom {
            position: relative;
            display: flex;
            align-items: center;
        }
        
        .input-group-custom .form-control,
        .input-group-custom .form-select {
            padding-left: 45px;
            height: 50px;
            border-radius: 8px;
            border: 2px solid #e3e6f0;
            transition: all 0.3s;
            font-size: 1rem;
        }
        
        .input-group-custom .form-control:focus,
        .input-group-custom .form-select:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 0.2rem rgba(78, 115, 223, 0.25);
        }
        
        .input-icon {
            position: absolute;
            left: 15px;
            color: #858796;
            font-size: 1.2rem;
            z-index: 4;
        }
        
        .form-text {
            font-size: 0.85rem;
            color: #6c757d;
            margin-top: 5px;
        }
        
        .btn-register {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border: none;
            border-radius: 8px;
            padding: 14px 30px;
            font-weight: 600;
            font-size: 1.1rem;
            color: white;
            width: 100%;
            transition: all 0.3s;
            margin-top: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
        }
        
        .btn-register:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(102, 126, 234, 0.3);
        }
        
        .btn-register:active {
            transform: translateY(0);
        }
        
        .login-link {
            text-align: center;
            margin-top: 20px;
            color: #6c757d;
        }
        
        .login-link a {
            color: var(--primary-color);
            text-decoration: none;
            font-weight: 600;
            transition: color 0.3s;
        }
        
        .login-link a:hover {
            color: #224abe;
            text-decoration: underline;
        }
        
        /* Alert Styles */
        .alert-custom {
            border-radius: 10px;
            border: none;
            padding: 15px 20px;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            animation: slideIn 0.3s ease-out;
        }
        
        @keyframes slideIn {
            from { transform: translateX(-20px); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
        }
        
        .alert-danger-custom {
            background: linear-gradient(135deg, #f8d7da 0%, #f5c6cb 100%);
            border-left: 4px solid var(--danger-color);
            color: #721c24;
        }
        
        .alert-success-custom {
            background: linear-gradient(135deg, #d4edda 0%, #c3e6cb 100%);
            border-left: 4px solid var(--secondary-color);
            color: #155724;
        }
        
        .alert-icon {
            font-size: 1.5rem;
            margin-right: 12px;
        }
        
        /* Password Strength */
        .password-strength {
            height: 5px;
            border-radius: 3px;
            margin-top: 5px;
            transition: all 0.3s;
        }
        
        .strength-weak {
            background: linear-gradient(90deg, #e74a3b, #f6c23e);
            width: 30%;
        }
        
        .strength-medium {
            background: linear-gradient(90deg, #f6c23e, #1cc88a);
            width: 60%;
        }
        
        .strength-strong {
            background: linear-gradient(90deg, #1cc88a, #4e73df);
            width: 100%;
        }
        
        /* Terms Checkbox */
        .terms-checkbox {
            background: var(--light-color);
            border-radius: 8px;
            padding: 15px;
            margin: 20px 0;
            border: 2px solid #e3e6f0;
        }
        
        .terms-checkbox .form-check-input:checked {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
        }
        
        .terms-checkbox .form-check-label {
            color: var(--dark-color);
            font-size: 0.95rem;
        }
        
        .terms-checkbox a {
            color: var(--primary-color);
            text-decoration: none;
            font-weight: 600;
        }
        
        .terms-checkbox a:hover {
            text-decoration: underline;
        }
        
        /* Responsive */
        @media (max-width: 768px) {
            .register-card {
                border-radius: 10px;
            }
            
            .card-header {
                padding: 20px;
            }
            
            .card-body {
                padding: 20px;
            }
            
            .brand-logo {
                font-size: 1.5rem;
            }
            
            .form-title {
                font-size: 1.3rem;
            }
        }
        
        /* Validation States */
        .is-valid {
            border-color: var(--secondary-color) !important;
        }
        
        .is-invalid {
            border-color: var(--danger-color) !important;
        }
        
        .invalid-feedback {
            color: var(--danger-color);
            font-size: 0.85rem;
            margin-top: 5px;
            display: block;
        }
    </style>
</head>

<body>
    <div class="register-container">
        <div class="register-card">
            <!-- Card Header -->
            <div class="card-header">
                <div class="brand-logo">
                    <i class="fas fa-tools"></i>
                    <span>Peminjamn Motor</span>
                </div>
                <p class="welcome-text">Bergabunglah dengan sistem peminjaman Motor</p>
            </div>
            
            <!-- Card Body -->
            <div class="card-body">
                <h3 class="form-title">
                    <i class="fas fa-user-plus"></i>
                    Buat Akun Baru
                </h3>
                
                <!-- Session Messages -->
                <?php 
                if (isset($_SESSION['register_errors'])): ?>
                    <div class="alert-custom alert-danger-custom">
                        <i class="fas fa-exclamation-triangle alert-icon"></i>
                        <div>
                            <?php 
                            foreach ($_SESSION['register_errors'] as $error) {
                                echo "<div>$error</div>";
                            }
                            unset($_SESSION['register_errors']);
                            ?>
                        </div>
                    </div>
                <?php endif; ?>
                
                <?php if (isset($_SESSION['register_success'])): ?>
                    <div class="alert-custom alert-success-custom">
                        <i class="fas fa-check-circle alert-icon"></i>
                        <div>
                            <?php 
                            echo $_SESSION['register_success'];
                            unset($_SESSION['register_success']);
                            ?>
                        </div>
                    </div>
                <?php endif; ?>

                <!-- Form Register -->
                <form action="../../../backend/action/auth/register_proses.php" method="POST" id="registerForm" class="needs-validation" novalidate>
                    <div class="row">
                        <!-- ID User -->
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="id" class="form-label required">ID User</label>
                                <div class="input-group-custom">
                                    <i class="fas fa-id-card input-icon"></i>
                                    <input type="number" class="form-control" id="id" name="id" 
                                           placeholder="Contoh: 1001" required min="1"
                                           value="<?php echo isset($_SESSION['register_data']['id']) ? htmlspecialchars($_SESSION['register_data']['id']) : ''; ?>">
                                </div>
                                <div class="form-text">ID harus unik dan belum terdaftar</div>
                                <div class="invalid-feedback">Harap masukkan ID user yang valid</div>
                            </div>
                        </div>
                        
                        <!-- Username -->
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="username" class="form-label required">Username</label>
                                <div class="input-group-custom">
                                    <i class="fas fa-user input-icon"></i>
                                    <input type="text" class="form-control" id="username" name="username" 
                                           placeholder="Masukkan username" required minlength="3"
                                           value="<?php echo isset($_SESSION['register_data']['username']) ? htmlspecialchars($_SESSION['register_data']['username']) : ''; ?>">
                                </div>
                                <div class="form-text">Minimal 3 karakter</div>
                                <div class="invalid-feedback">Username minimal 3 karakter</div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Nama Lengkap -->
                    <div class="form-group">
                        <label for="nama_lengkap" class="form-label required">Nama Lengkap</label>
                        <div class="input-group-custom">
                            <i class="fas fa-user-tag input-icon"></i>
                            <input type="text" class="form-control" id="nama_lengkap" name="nama_lengkap" 
                                   placeholder="Masukkan nama lengkap" required
                                   value="<?php echo isset($_SESSION['register_data']['nama_lengkap']) ? htmlspecialchars($_SESSION['register_data']['nama_lengkap']) : ''; ?>">
                        </div>
                        <div class="invalid-feedback">Harap masukkan nama lengkap</div>
                    </div>
                    
                    <div class="row">
                        <!-- Email -->
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="email" class="form-label">Email</label>
                                <div class="input-group-custom">
                                    <i class="fas fa-envelope input-icon"></i>
                                    <input type="email" class="form-control" id="email" name="email" 
                                           placeholder="nama@contoh.com"
                                           value="<?php echo isset($_SESSION['register_data']['email']) ? htmlspecialchars($_SESSION['register_data']['email']) : ''; ?>">
                                </div>
                                <div class="form-text">Opsional</div>
                            </div>
                        </div>
                        
                        <!-- No Telepon -->
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="no_telp" class="form-label">No. Telepon</label>
                                <div class="input-group-custom">
                                    <i class="fas fa-phone input-icon"></i>
                                    <input type="tel" class="form-control" id="no_telp" name="no_telp" 
                                           placeholder="081234567890"
                                           value="<?php echo isset($_SESSION['register_data']['no_telp']) ? htmlspecialchars($_SESSION['register_data']['no_telp']) : ''; ?>">
                                </div>
                                <div class="form-text">Opsional</div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="row">
                        <!-- Password -->
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="password" class="form-label required">Password</label>
                                <div class="input-group-custom">
                                    <i class="fas fa-lock input-icon"></i>
                                    <input type="password" class="form-control" id="password" name="password" 
                                           placeholder="Masukkan password" required minlength="6">
                                    <button type="button" class="password-toggle" onclick="togglePassword('password')">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                </div>
                                <div class="form-text">Minimal 6 karakter</div>
                                <div class="password-strength" id="passwordStrength"></div>
                                <div class="invalid-feedback">Password minimal 6 karakter</div>
                            </div>
                        </div>
                        
                        <!-- Confirm Password -->
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="confirm_password" class="form-label required">Konfirmasi Password</label>
                                <div class="input-group-custom">
                                    <i class="fas fa-lock input-icon"></i>
                                    <input type="password" class="form-control" id="confirm_password" name="confirm_password" 
                                           placeholder="Konfirmasi password" required>
                                    <button type="button" class="password-toggle" onclick="togglePassword('confirm_password')">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                </div>
                                <div class="form-text">Harus sama dengan password</div>
                                <div class="invalid-feedback">Konfirmasi password harus sama</div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Alamat -->
                    <div class="form-group">
                        <label for="alamat" class="form-label">Alamat</label>
                        <div class="input-group-custom">
                            <i class="fas fa-home input-icon"></i>
                            <textarea class="form-control" id="alamat" name="alamat" 
                                      placeholder="Masukkan alamat lengkap" rows="3"><?php echo isset($_SESSION['register_data']['alamat']) ? htmlspecialchars($_SESSION['register_data']['alamat']) : ''; ?></textarea>
                        </div>
                        <div class="form-text">Opsional</div>
                    </div>
                    
                    <!-- Terms and Conditions -->
                    <div class="terms-checkbox">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" id="terms" required>
                            <label class="form-check-label" for="terms">
                                Saya menyetujui <a href="#">Syarat dan Ketentuan</a> serta <a href="#">Kebijakan Privasi</a>
                            </label>
                            <div class="invalid-feedback">Anda harus menyetujui syarat dan ketentuan</div>
                        </div>
                    </div>

                    <!-- Submit Button -->
                    <button type="submit" class="btn btn-register" id="registerBtn">
                        <i class="fas fa-user-plus"></i>
                        <span id="btnText">Daftar Sekarang</span>
                        <span id="btnLoading" class="d-none">
                            <span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
                            Memproses...
                        </span>
                    </button>
                    
                    <!-- Login Link -->
                    <div class="login-link">
                        Sudah punya akun? <a href="login.php">Login di sini</a>
                    </div>
                </form>
                <!-- End Form Register -->
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
        // Clear session data
        <?php unset($_SESSION['register_data']); ?>
        
        // Password Toggle
        function togglePassword(fieldId) {
            const passwordInput = document.getElementById(fieldId);
            const toggleBtn = passwordInput.nextElementSibling;
            const icon = toggleBtn.querySelector('i');
            
            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';
                icon.classList.remove('fa-eye');
                icon.classList.add('fa-eye-slash');
            } else {
                passwordInput.type = 'password';
                icon.classList.remove('fa-eye-slash');
                icon.classList.add('fa-eye');
            }
        }
        
        // Password Strength Indicator
        document.getElementById('password').addEventListener('input', function() {
            const strengthBar = document.getElementById('passwordStrength');
            const password = this.value;
            
            // Reset
            strengthBar.className = 'password-strength';
            
            if (password.length === 0) return;
            
            // Calculate strength
            let strength = 0;
            if (password.length >= 6) strength++;
            if (password.length >= 8) strength++;
            if (/[A-Z]/.test(password)) strength++;
            if (/[0-9]/.test(password)) strength++;
            if (/[^A-Za-z0-9]/.test(password)) strength++;
            
            // Update strength bar
            if (strength <= 2) {
                strengthBar.classList.add('strength-weak');
            } else if (strength <= 4) {
                strengthBar.classList.add('strength-medium');
            } else {
                strengthBar.classList.add('strength-strong');
            }
        });
        
        // Form Validation
        document.getElementById('registerForm').addEventListener('submit', function(e) {
            const form = this;
            const registerBtn = document.getElementById('registerBtn');
            const btnText = document.getElementById('btnText');
            const btnLoading = document.getElementById('btnLoading');
            
            // Check form validity
            if (!form.checkValidity()) {
                e.preventDefault();
                e.stopPropagation();
                form.classList.add('was-validated');
                return;
            }
            
            // Check password match
            const password = document.getElementById('password').value;
            const confirmPassword = document.getElementById('confirm_password').value;
            
            if (password !== confirmPassword) {
                e.preventDefault();
                e.stopPropagation();
                document.getElementById('confirm_password').classList.add('is-invalid');
                document.getElementById('confirm_password').nextElementSibling.innerHTML = 'Konfirmasi password tidak sama';
                return;
            }
            
            // Disable button and show loading
            registerBtn.disabled = true;
            btnText.classList.add('d-none');
            btnLoading.classList.remove('d-none');
            
            // Prevent double submission
            setTimeout(() => {
                if (!registerBtn.disabled) {
                    registerBtn.disabled = false;
                    btnText.classList.remove('d-none');
                    btnLoading.classList.add('d-none');
                }
            }, 5000);
        });
        
        // Real-time validation
        const inputs = document.querySelectorAll('#registerForm input, #registerForm textarea');
        inputs.forEach(input => {
            input.addEventListener('input', function() {
                if (this.checkValidity()) {
                    this.classList.remove('is-invalid');
                    this.classList.add('is-valid');
                } else {
                    this.classList.remove('is-valid');
                    this.classList.add('is-invalid');
                }
                
                // Special validation for confirm password
                if (this.id === 'confirm_password') {
                    const password = document.getElementById('password').value;
                    if (this.value !== password && this.value.length > 0) {
                        this.classList.remove('is-valid');
                        this.classList.add('is-invalid');
                    } else if (this.value === password && this.value.length >= 6) {
                        this.classList.remove('is-invalid');
                        this.classList.add('is-valid');
                    }
                }
            });
        });
        
        // Auto-focus on first input
        document.addEventListener('DOMContentLoaded', function() {
            document.getElementById('id').focus();
            
            // Fetch last ID for suggestion
            fetch('../../../backend/action/auth/get_last_id.php')
                .then(response => response.json())
                .then(data => {
                    if (data.last_id && data.last_id > 0 && !document.getElementById('id').value) {
                        document.getElementById('id').value = parseInt(data.last_id) + 1;
                    }
                })
                .catch(error => console.error('Error:', error));
                
            // Clear URL parameters
            if (window.history.replaceState) {
                window.history.replaceState(null, null, window.location.pathname);
            }
        });
        
        // Enter key to submit form
        document.addEventListener('keypress', function(e) {
            if (e.key === 'Enter' && !document.getElementById('registerBtn').disabled) {
                document.getElementById('registerForm').submit();
            }
        });
    </script>
</body>
</html>