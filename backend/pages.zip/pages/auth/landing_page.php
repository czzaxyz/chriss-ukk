<?php
session_start();

// Jika sudah login, redirect ke dashboard sesuai role
if (isset($_SESSION['user_id']) && isset($_SESSION['role'])) {
    switch($_SESSION['role']) {
        case 'admin':
            header("Location: ../../admin/pages/dashboard/index.php");
            exit();
        case 'petugas':
            header("Location: ../../petugas/pages/dashboard/index.php");
            exit();
        case 'peminjam':
            header("Location: ../../peminjaman/pages/dashboard/index.php");
            exit();
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MoToR - Upgrade Your Ride Today</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        body {
            background-color: #0f1419;
            color: #fff;
            line-height: 1.6;
            overflow-x: hidden;
        }
        
        /* Bagian Atas dengan Video Background */
        .top-section {
            position: relative;
            height: 100vh;
            min-height: 700px;
            overflow: hidden;
            border-bottom: 2px solid #fff;
            box-shadow: 0 0 20px rgba(255, 255, 255, 0.2);
        }
        
        .video-container {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: 1;
            border: 1px solid rgba(255, 255, 255, 0.3);
        }
        
        #hero-video {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        
        .video-overlay {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(
                to bottom, 
                rgba(15, 20, 25, 0.95) 0%, 
                rgba(15, 20, 25, 0.7) 50%, 
                rgba(15, 20, 25, 0.4) 70%,
                rgba(15, 20, 25, 0.2) 85%,
                rgba(15, 20, 25, 0) 100%
            );
            z-index: 2;
            box-shadow: inset 0 0 0 1px rgba(255, 255, 255, 0.2);
        }
        
        /* Fallback jika video tidak dapat dimuat */
        .video-fallback {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(135deg, #0f1419 0%, #1a1f27 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 24px;
            z-index: 1;
            border: 2px solid #fff;
            display: none;
        }
        
        /* Garis putih dekoratif di sudut video */
        .video-border-corner {
            position: absolute;
            width: 30px;
            height: 30px;
            z-index: 3;
        }
        
        .video-border-corner.top-left {
            top: 20px;
            left: 20px;
            border-top: 2px solid #fff;
            border-left: 2px solid #fff;
        }
        
        .video-border-corner.top-right {
            top: 20px;
            right: 20px;
            border-top: 2px solid #fff;
            border-right: 2px solid #fff;
        }
        
        .video-border-corner.bottom-left {
            bottom: 20px;
            left: 20px;
            border-bottom: 2px solid #fff;
            border-left: 2px solid #fff;
        }
        
        .video-border-corner.bottom-right {
            bottom: 20px;
            right: 20px;
            border-bottom: 2px solid #fff;
            border-right: 2px solid #fff;
        }
        
        /* Konten di atas video */
        .top-content {
            position: relative;
            z-index: 3;
            height: 100%;
            display: flex;
            flex-direction: column;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
        }
        
        /* Header Styles */
        header {
            padding: 20px 0;
        }
        
        .header-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .logo {
            font-size: 32px;
            font-weight: 800;
            letter-spacing: 2px;
            color: #ff2d8e;
            text-decoration: none;
        }
        
        .logo span {
            color: #fff;
        }
        
        .nav-links {
            display: flex;
            gap: 30px;
        }
        
        .nav-links a {
            color: #fff;
            text-decoration: none;
            font-weight: 600;
            font-size: 16px;
            transition: color 0.3s;
            position: relative;
        }
        
        .nav-links a::after {
            content: '';
            position: absolute;
            bottom: -5px;
            left: 0;
            width: 0;
            height: 2px;
            background: #fff;
            transition: width 0.3s;
        }
        
        .nav-links a:hover::after {
            width: 100%;
        }
        
        .nav-links a:hover {
            color: #ff2d8e;
        }
        
        .cta-button {
            background-color: #ff2d8e;
            color: white;
            border: none;
            padding: 12px 28px;
            border-radius: 30px;
            font-weight: 700;
            font-size: 16px;
            cursor: pointer;
            transition: all 0.3s;
            text-decoration: none;
            display: inline-block;
            border: 2px solid transparent;
        }
        
        .cta-button:hover {
            background-color: transparent;
            border-color: #ff2d8e;
            color: #ff2d8e;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(255, 45, 142, 0.3);
        }
        
        /* Hero Section */
        .hero {
            flex: 1;
            display: flex;
            align-items: center;
            padding: 40px 0;
        }
        
        .hero-content {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 60px;
            align-items: center;
        }
        
        .hero-text h1 {
            font-size: 48px;
            line-height: 1.2;
            margin-bottom: 20px;
            position: relative;
            padding-bottom: 20px;
        }
        
        .hero-text h1::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 100px;
            height: 3px;
            background: #fff;
        }
        
        .hero-text h1 span {
            color: #ff2d8e;
        }
        
        .hero-text p {
            font-size: 18px;
            color: #aaa;
            margin-bottom: 30px;
            max-width: 500px;
        }
        
        .hero-image {
            position: relative;
            border: 2px solid rgba(255, 255, 255, 0.3);
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.5);
        }
        
        .hero-image video {
            width: 100%;
            height: 100%;
            object-fit: cover;
            animation: float 3s ease-in-out infinite;
        }
        
        @keyframes float {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-10px); }
        }
        
        /* Scroll Indicator */
        .scroll-indicator {
            position: absolute;
            bottom: 50px;
            left: 50%;
            transform: translateX(-50%);
            z-index: 4;
            text-align: center;
            color: #fff;
            animation: bounce 2s infinite;
        }
        
        .scroll-indicator i {
            font-size: 24px;
            margin-bottom: 10px;
            display: block;
            color: #fff;
        }
        
        .scroll-indicator-text {
            font-size: 14px;
            letter-spacing: 2px;
            text-transform: uppercase;
            color: #fff;
        }
        
        /* Garis di scroll indicator */
        .scroll-line {
            width: 1px;
            height: 40px;
            background: #fff;
            margin: 10px auto;
            position: relative;
            overflow: hidden;
        }
        
        .scroll-line::after {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 20px;
            background: linear-gradient(to bottom, transparent, #fff, transparent);
            animation: lineFlow 2s infinite;
        }
        
        @keyframes bounce {
            0%, 20%, 50%, 80%, 100% { transform: translateY(0) translateX(-50%); }
            40% { transform: translateY(-10px) translateX(-50%); }
            60% { transform: translateY(-5px) translateX(-50%); }
        }
        
        @keyframes lineFlow {
            0% { transform: translateY(-20px); }
            100% { transform: translateY(40px); }
        }
        
        /* Garis pemisah antara top section dan main content */
        .section-divider {
            position: relative;
            height: 2px;
            background: #fff;
            margin: 0 auto;
            width: 80%;
            max-width: 800px;
            margin-top: -1px;
        }
        
        .section-divider::before,
        .section-divider::after {
            content: '';
            position: absolute;
            top: -10px;
            width: 20px;
            height: 20px;
            border: 2px solid #fff;
            transform: rotate(45deg);
            background: #0f1419;
        }
        
        .section-divider::before {
            left: -10px;
        }
        
        .section-divider::after {
            right: -10px;
        }
        
        /* Bagian Bawah (Setelah Video) */
        .main-content {
            background-color: #0f1419;
            position: relative;
            z-index: 4;
            padding-top: 80px;
        }
        
        /* Stats Section */
        .stats {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 30px;
            margin: 80px 0;
        }
        
        .stat-card {
            background: rgba(255, 255, 255, 0.05);
            border-radius: 15px;
            padding: 25px 20px;
            text-align: center;
            transition: transform 0.3s;
            border: 1px solid rgba(255, 255, 255, 0.1);
        }
        
        .stat-card:hover {
            transform: translateY(-5px);
            background: rgba(255, 255, 255, 0.08);
            border-color: #ff2d8e;
        }
        
        .stat-value {
            font-size: 32px;
            font-weight: 800;
            color: #ff2d8e;
            margin-bottom: 5px;
        }
        
        .stat-label {
            font-size: 14px;
            color: #aaa;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        
        /* Features Section */
        .features {
            margin-bottom: 100px;
        }
        
        .section-title {
            text-align: center;
            font-size: 36px;
            margin-bottom: 50px;
            color: #fff;
            position: relative;
            padding-bottom: 20px;
        }
        
        .section-title::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 50%;
            transform: translateX(-50%);
            width: 100px;
            height: 3px;
            background: #ff2d8e;
        }
        
        .features-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 30px;
        }
        
        .feature-card {
            background: rgba(255, 255, 255, 0.05);
            border-radius: 15px;
            padding: 30px;
            text-align: center;
            transition: all 0.3s;
            border: 1px solid rgba(255, 255, 255, 0.1);
            position: relative;
            overflow: hidden;
        }
        
        .feature-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 3px;
            background: #ff2d8e;
            transform: translateX(-100%);
            transition: transform 0.3s;
        }
        
        .feature-card:hover::before {
            transform: translateX(0);
        }
        
        .feature-card:hover {
            transform: translateY(-10px);
            background: rgba(255, 255, 255, 0.08);
            border-color: #ff2d8e;
            box-shadow: 0 15px 30px rgba(255, 45, 142, 0.2);
        }
        
        .feature-icon {
            font-size: 40px;
            color: #ff2d8e;
            margin-bottom: 20px;
        }
        
        .feature-card h3 {
            font-size: 22px;
            margin-bottom: 15px;
        }
        
        .feature-card p {
            color: #aaa;
            font-size: 16px;
        }
        
        /* Reviews Section */
        .reviews {
            margin-bottom: 100px;
        }
        
        .review-badge {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 15px;
            margin-bottom: 40px;
        }
        
        .review-badge span {
            font-size: 48px;
            font-weight: 800;
            color: #ff2d8e;
        }
        
        .review-badge p {
            font-size: 18px;
            color: #aaa;
        }
        
        .partner-logos {
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 50px;
            flex-wrap: wrap;
            margin-top: 50px;
        }
        
        .partner-logos div {
            font-size: 32px;
            font-weight: 800;
            color: #aaa;
            padding: 10px 20px;
            border: 1px solid rgba(255, 255, 255, 0.2);
            border-radius: 10px;
            transition: all 0.3s;
        }
        
        .partner-logos div:hover {
            color: #fff;
            border-color: #ff2d8e;
            transform: translateY(-5px);
        }
        
        /* Footer */
        footer {
            background-color: #080c10;
            padding: 60px 0 30px;
            text-align: center;
            border-top: 2px solid #fff;
            position: relative;
        }
        
        .footer-content {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 30px;
        }
        
        .footer-cta {
            font-size: 28px;
            margin-bottom: 20px;
            position: relative;
            padding-bottom: 20px;
        }
        
        .footer-cta::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 50%;
            transform: translateX(-50%);
            width: 100px;
            height: 2px;
            background: #ff2d8e;
        }
        
        .footer-logo {
            font-size: 40px;
            font-weight: 800;
            letter-spacing: 3px;
            color: #ff2d8e;
            margin-bottom: 10px;
        }
        
        .footer-logo span {
            color: #fff;
        }
        
        .footer-text {
            color: #aaa;
            max-width: 600px;
            margin-bottom: 30px;
        }
        
        .copyright {
            color: #666;
            font-size: 14px;
            margin-top: 40px;
            padding-top: 20px;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
        }
        
        /* Video Controls */
        .video-controls {
            position: fixed;
            bottom: 20px;
            right: 20px;
            z-index: 100;
            display: flex;
            gap: 10px;
        }
        
        .video-btn {
            background: rgba(255, 255, 255, 0.1);
            border: 1px solid rgba(255, 255, 255, 0.3);
            color: white;
            width: 40px;
            height: 40px;
            border-radius: 50%;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.3s;
        }
        
        .video-btn:hover {
            background: rgba(255, 45, 142, 0.8);
            transform: scale(1.1);
            border-color: #ff2d8e;
        }
        
        /* Responsive Design */
        @media (max-width: 992px) {
            .hero-content {
                grid-template-columns: 1fr;
                text-align: center;
            }
            
            .hero-text h1::after {
                left: 50%;
                transform: translateX(-50%);
            }
            
            .hero-text p {
                margin: 0 auto 30px;
            }
            
            .stats {
                grid-template-columns: repeat(2, 1fr);
            }
            
            .features-grid {
                grid-template-columns: repeat(2, 1fr);
            }
            
            .top-section {
                min-height: 600px;
            }
        }
        
        @media (max-width: 768px) {
            .header-content {
                flex-direction: column;
                gap: 20px;
            }
            
            .nav-links {
                gap: 20px;
            }
            
            .hero-text h1 {
                font-size: 36px;
            }
            
            .features-grid {
                grid-template-columns: 1fr;
            }
            
            .partner-logos {
                gap: 30px;
            }
            
            .partner-logos div {
                font-size: 24px;
                padding: 8px 16px;
            }
            
            .top-section {
                height: auto;
                min-height: 500px;
            }
            
            .video-border-corner {
                display: none;
            }
        }
        
        @media (max-width: 576px) {
            .stats {
                grid-template-columns: 1fr;
            }
            
            .nav-links {
                flex-wrap: wrap;
                justify-content: center;
            }
            
            .cta-button {
                padding: 10px 20px;
                font-size: 14px;
            }
            
            .scroll-indicator {
                display: none;
            }
            
            .section-divider {
                width: 90%;
            }
        }
    </style>
</head>
<body>
    <!-- Bagian Atas dengan Video Background -->
    <div class="top-section">
        <!-- Garis putih di sudut video -->
        <div class="video-border-corner top-left"></div>
        <div class="video-border-corner top-right"></div>
        <div class="video-border-corner bottom-left"></div>
        <div class="video-border-corner bottom-right"></div>
        
        <!-- Video Background -->
        <div class="video-container">
            <!-- PERBAIKAN DI SINI: Menggunakan tag source yang benar -->
            <video id="hero-video" autoplay muted loop playsinline>
                <source src="../../../storages/video/motor.mp4" type="video/mp4">
                <!-- Fallback jika video lokal tidak tersedia -->
                <source src="https://assets.mixkit.co/videos/preview/mixkit-motorcycle-driving-fast-on-the-road-3454-large.mp4" type="video/mp4">
                <source src="https://cdn.pixabay.com/video/2023/02/22/159655-806789351_large.mp4" type="video/mp4">
                Browser Anda tidak mendukung tag video.
            </video>
            <div class="video-fallback" id="video-fallback">
                <div style="text-align: center;">
                    <i class="fas fa-motorcycle" style="font-size: 48px; margin-bottom: 20px; color: #ff2d8e;"></i>
                    <p>MoToR - Upgrade Your Ride</p>
                    <p style="font-size: 16px; margin-top: 10px;">Experience the thrill of the road</p>
                </div>
            </div>
            <div class="video-overlay"></div>
        </div>
        
        <!-- Konten di atas video -->
        <div class="top-content container">
            <!-- Header -->
            <header>
                <div class="header-content">
                    <a href="#" class="logo">Mo<span>To</span>R</a>
                    <!-- Tombol Login -->
                    <a href="./login.php" class="cta-button">
                        <i class="fas fa-sign-in-alt"></i> Login
                    </a>
                </div>
            </header>

            <!-- Hero Section -->
            <section class="hero">
                <div class="hero-content">
                    <div class="hero-text">
                        <h1>Upgrade your <span>ride today.</span> MoToR</h1>
                        <p>Upgrade your ride today with exclusive deals on bikes and gear. Join now and be part of a community of passionate riders!</p>
                        <div style="display: flex; gap: 15px; margin-top: 30px;">
                            <a href="./login.php" class="cta-button" style="padding: 15px 35px;">
                                <i class="fas fa-sign-in-alt"></i> Get Started
                            </a>
                        </div>
                    </div>
                </div>
            </section>
            
            <!-- Scroll Indicator -->
            <div class="scroll-indicator">
                <div class="scroll-line"></div>
                <div class="scroll-indicator-text">Scroll to explore</div>
            </div>
        </div>
    </div>
    
    <!-- Garis pemisah -->
    <div class="section-divider"></div>
    
    <!-- Video Controls -->
    <div class="video-controls">
        <button class="video-btn" id="play-pause">
            <i class="fas fa-pause"></i>
        </button>
        <button class="video-btn" id="mute-unmute">
            <i class="fas fa-volume-up"></i>
        </button>
    </div>

    <!-- Bagian Bawah (Setelah Video) -->
    <div class="main-content">
        <!-- Stats Section -->
        <section class="container" id="stats">
            <div class="stats">
                <div class="stat-card">
                    <div class="stat-value">25km/h</div>
                    <div class="stat-label">Assist Speed</div>
                </div>
                <div class="stat-card">
                    <div class="stat-value">70km</div>
                    <div class="stat-label">Battery Range</div>
                </div>
                <div class="stat-card">
                    <div class="stat-value">3.5h</div>
                    <div class="stat-label">Charging Time</div>
                </div>
                <div class="stat-card">
                    <div class="stat-value">16.9kg</div>
                    <div class="stat-label">Weight</div>
                </div>
            </div>
        </section>

        <!-- Features Section -->
        <section class="features" id="features">
            <div class="container">
                <h2 class="section-title">Why Choose MoToR</h2>
                <div class="features-grid">
                    <div class="feature-card">
                        <div class="feature-icon">
                            <i class="fas fa-bolt"></i>
                        </div>
                        <h3>Instant Acceleration</h3>
                        <p>Experience instant torque and rapid acceleration with our advanced electric motor technology.</p>
                    </div>
                    <div class="feature-card">
                        <div class="feature-icon">
                            <i class="fas fa-battery-full"></i>
                        </div>
                        <h3>Long-Lasting Battery</h3>
                        <p>Ride further with our high-capacity battery that provides up to 70km on a single charge.</p>
                    </div>
                    <div class="feature-card">
                        <div class="feature-icon">
                            <i class="fas fa-tachometer-alt"></i>
                        </div>
                        <h3>Smart Dashboard</h3>
                        <p>Stay connected with our integrated smart dashboard with navigation and ride statistics.</p>
                    </div>
                </div>
            </div>
        </section>

        <!-- Reviews Section -->
        <section class="reviews" id="reviews">
            <div class="container">
                <div class="review-badge">
                    <span>1000+</span>
                    <p>reviews from passionate riders</p>
                </div>
                <h2 class="section-title">Trusted by Industry Leaders</h2>
                <div class="partner-logos">
                    <div>ZOOM</div>
                    <div>NETFLIX</div>
                    <div>SAMSUNG</div>
                </div>
            </div>
        </section>

        <!-- Footer -->
        <footer id="about">
            <div class="container">
                <div class="footer-content">
                    <h2 class="footer-cta">Upgrade your ride today</h2>
                    <div class="footer-logo">Mo<span>To</span>R</div>
                    <p class="footer-text">Join thousands of riders who have already upgraded their ride. Experience the future of electric mobility today.</p>
                    <a href="./login.php" class="cta-button" style="padding: 15px 40px; font-size: 18px;">
                        <i class="fas fa-rocket"></i> Start Your Journey
                    </a>
                    <p class="copyright">&copy; 2023 MoToR. All rights reserved.</p>
                </div>
            </div>
        </footer>
    </div>

    <script>
        // Kontrol Video Background
        const video = document.getElementById('hero-video');
        const playPauseBtn = document.getElementById('play-pause');
        const muteBtn = document.getElementById('mute-unmute');
        const videoFallback = document.getElementById('video-fallback');
        
        // Coba memuat video dari sumber pertama
        let currentVideoIndex = 0;
        const videoSources = [
            '../../../storages/video/motor.mp4',
            'https://assets.mixkit.co/videos/preview/mixkit-motorcycle-driving-fast-on-the-road-3454-large.mp4',
            'https://cdn.pixabay.com/video/2023/02/22/159655-806789351_large.mp4'
        ];
        
        // Fungsi untuk mencoba sumber video berikutnya
        function tryNextVideoSource() {
            currentVideoIndex++;
            if (currentVideoIndex < videoSources.length) {
                video.src = videoSources[currentVideoIndex];
                video.load();
                video.play().catch(e => {
                    console.log(`Video source ${currentVideoIndex} failed, trying next...`);
                    setTimeout(tryNextVideoSource, 500);
                });
            } else {
                // Semua sumber gagal, tampilkan fallback
                console.log('All video sources failed, showing fallback');
                video.style.display = 'none';
                videoFallback.style.display = 'flex';
                document.querySelector('.video-controls').style.display = 'none';
            }
        }
        
        // Coba memuat video pertama
        video.load();
        video.play().catch(e => {
            console.log('First video source failed, trying alternatives...');
            tryNextVideoSource();
        });
        
        // Play/Pause functionality
        playPauseBtn.addEventListener('click', function() {
            if (video.style.display === 'none') return;
            
            if (video.paused) {
                video.play();
                this.innerHTML = '<i class="fas fa-pause"></i>';
            } else {
                video.pause();
                this.innerHTML = '<i class="fas fa-play"></i>';
            }
        });
        
        // Mute/Unmute functionality
        muteBtn.addEventListener('click', function() {
            if (video.style.display === 'none') return;
            
            if (video.muted) {
                video.muted = false;
                this.innerHTML = '<i class="fas fa-volume-up"></i>';
            } else {
                video.muted = true;
                this.innerHTML = '<i class="fas fa-volume-mute"></i>';
            }
        });
        
        // Update tombol berdasarkan status video
        video.addEventListener('play', function() {
            playPauseBtn.innerHTML = '<i class="fas fa-pause"></i>';
        });
        
        video.addEventListener('pause', function() {
            playPauseBtn.innerHTML = '<i class="fas fa-play"></i>';
        });
        
        video.addEventListener('volumechange', function() {
            if (video.muted) {
                muteBtn.innerHTML = '<i class="fas fa-volume-mute"></i>';
            } else {
                muteBtn.innerHTML = '<i class="fas fa-volume-up"></i>';
            }
        });
        
        // Animasi untuk stat cards saat scroll
        window.addEventListener('scroll', function() {
            const statCards = document.querySelectorAll('.stat-card');
            const featureCards = document.querySelectorAll('.feature-card');
            const windowHeight = window.innerHeight;
            
            // Animate stat cards
            statCards.forEach(card => {
                const cardPosition = card.getBoundingClientRect().top;
                if (cardPosition < windowHeight - 100) {
                    card.style.opacity = '1';
                    card.style.transform = 'translateY(0)';
                }
            });
            
            // Animate feature cards
            featureCards.forEach(card => {
                const cardPosition = card.getBoundingClientRect().top;
                if (cardPosition < windowHeight - 100) {
                    card.style.opacity = '1';
                    card.style.transform = 'translateY(0)';
                }
            });
            
            // Hide scroll indicator saat scroll ke bawah
            const scrollIndicator = document.querySelector('.scroll-indicator');
            if (window.scrollY > 100) {
                scrollIndicator.style.opacity = '0';
                scrollIndicator.style.pointerEvents = 'none';
            } else {
                scrollIndicator.style.opacity = '1';
                scrollIndicator.style.pointerEvents = 'auto';
            }
        });
        
        // Inisialisasi animasi
        document.addEventListener('DOMContentLoaded', function() {
            // Inisialisasi stat cards
            const statCards = document.querySelectorAll('.stat-card');
            statCards.forEach(card => {
                card.style.opacity = '0';
                card.style.transform = 'translateY(20px)';
                card.style.transition = 'opacity 0.5s, transform 0.5s';
            });
            
            // Inisialisasi feature cards
            const featureCards = document.querySelectorAll('.feature-card');
            featureCards.forEach(card => {
                card.style.opacity = '0';
                card.style.transform = 'translateY(20px)';
                card.style.transition = 'opacity 0.5s, transform 0.5s';
            });
            
            // Trigger animation setelah halaman dimuat
            setTimeout(() => {
                window.dispatchEvent(new Event('scroll'));
            }, 500);
            
            // Smooth scrolling untuk anchor links
            document.querySelectorAll('a[href^="#"]').forEach(anchor => {
                anchor.addEventListener('click', function(e) {
                    e.preventDefault();
                    const target = document.querySelector(this.getAttribute('href'));
                    if (target) {
                        const headerHeight = 80;
                        const targetPosition = target.offsetTop - headerHeight;
                        
                        window.scrollTo({
                            top: targetPosition,
                            behavior: 'smooth'
                        });
                    }
                });
            });
            
            // Hide video controls on mobile
            if (window.innerWidth <= 768) {
                document.querySelector('.video-controls').style.display = 'none';
            }
        });
        
        // Parallax effect untuk video
        window.addEventListener('scroll', function() {
            const scrolled = window.pageYOffset;
            const videoContainer = document.querySelector('.video-container');
            const rate = scrolled * -0.5;
            
            if (scrolled < window.innerHeight) {
                videoContainer.style.transform = 'translate3d(0px, ' + rate + 'px, 0px)';
            }
        });
        
        // Hover effect untuk garis sudut
        const corners = document.querySelectorAll('.video-border-corner');
        corners.forEach(corner => {
            corner.addEventListener('mouseenter', function() {
                this.style.borderColor = '#ff2d8e';
                this.style.transform = 'scale(1.2)';
                this.style.transition = 'all 0.3s';
            });
            
            corner.addEventListener('mouseleave', function() {
                this.style.borderColor = '#fff';
                this.style.transform = 'scale(1)';
            });
        });
    </script>
</body>
</html>